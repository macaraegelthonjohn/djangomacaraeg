from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='app1_index'),  # Homepage for App1
    path('about/', views.about, name='app1_about'),  # About page for App1
    path('contact/', views.contact, name='app1_contact'),  # Contact page for App1
]

